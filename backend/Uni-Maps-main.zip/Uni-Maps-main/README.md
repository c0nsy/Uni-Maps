# Uni Maps

Uni Maps by Max Dann and Connor Logan

This is a project taken on in an attempt to create a "google maps for laurier" by mapping every entrance/exit to every building on campus.
Front end HTML/CSS/JS website designed by Connor Logan;
Back end Python graph designed by Max Dann

Backend uses Dijkstras algorithm to find the shortest path between nodes, along with some logic so that the user would only walk to connector nodes as opposed to through buildings.
